package com.metanit;

public interface Printable {
    void println();
}
